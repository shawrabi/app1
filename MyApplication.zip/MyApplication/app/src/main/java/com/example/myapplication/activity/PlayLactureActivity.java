package com.example.myapplication.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import com.example.myapplication.R;

public class PlayLactureActivity extends AppCompatActivity {

    TextView userid,videourl;
    String videourls,userids;
    EditText First,Second;
    Button Addition;
    TextView Result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_lacture);

        if (getIntent().hasExtra("userid"))
            userids = getIntent().getStringExtra("userid");
        if (getIntent().hasExtra("videourl"))
            videourls = getIntent().getStringExtra("videourl");

        userid = findViewById(R.id.userid);
        videourl = findViewById(R.id.videourl);
        First = (EditText)findViewById(R.id.first);
        Second = (EditText)findViewById(R.id.second);
        Addition = (Button)findViewById(R.id.addition);
        Result = (TextView)findViewById(R.id.result);

        if (!Python.isStarted())
            Python.start(new AndroidPlatform(this));
        Python py = Python.getInstance();
        //final PyObject pobj = py.getModule("collectData");
        final PyObject pobj = py.getModule("demo");


        Addition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PyObject obj=pobj.callAttr("sumtwo",First.getText().toString(),Second.getText().toString());
                //PyObject obj=pobj.callAttr("success",First.getText().toString());
                Result.setText(obj.toString());
            }
        });
        userid.setText(userids);
        videourl.setText(videourls);

    }
}