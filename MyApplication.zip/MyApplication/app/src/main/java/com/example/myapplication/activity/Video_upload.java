/*
package com.example.myapplication.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Video_upload extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText le_userid;
    EditText urername;
    String le_subject;
    EditText video_discreption;
    EditText module_no;
    EditText video_no;
    String file_address;
    Button le_submitBtn;
    FirebaseFirestore firebaseFirestore;
    DocumentReference ref;
    FirebaseFirestore db;
    Spinner spinnersubject;
    ImageView iv_attachments;
    TextView txt_upload;
    String[] subject = { "Machine Learning","Data Science","Algorithmic Toolbox","Network Security"};

    private Uri filePath;
    private final int PICK_IMAGE_REQUEST = 71;

    //firebase objects
    private StorageReference storageReference;
    private DatabaseReference mDatabase;
    String slected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_upload);
        le_submitBtn=findViewById(R.id.submitBtn);
        le_userid=findViewById(R.id.userid);
        urername=findViewById(R.id.userid);
        le_subject="ML";
        video_discreption=findViewById(R.id.Video_Discreaption);
        module_no=findViewById(R.id.Module_No);
        video_no=findViewById(R.id.Leacture_No);
        spinnersubject = findViewById(R.id.spinnersubject);
        iv_attachments = findViewById(R.id.iv_attachments);
        txt_upload = findViewById(R.id.txt_upload);
        storageReference = FirebaseStorage.getInstance().getReference();
        mDatabase = FirebaseDatabase.getInstance().getReference(Constants.DATABASE_PATH_UPLOADS);

        spinnersubject.setOnItemSelectedListener(this);

        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,subject);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spinnersubject.setAdapter(aa);

        firebaseFirestore=FirebaseFirestore.getInstance();
        ref = firebaseFirestore.collection("teacher").document();

        le_submitBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                if(le_userid.getText().toString().equals("")) {
                    Toast.makeText(Video_upload.this, "Please type a username", Toast.LENGTH_SHORT).show();

                }else if(urername.getText().toString().equals("")) {
                    Toast.makeText(Video_upload.this, "Please type an email id", Toast.LENGTH_SHORT).show();

                }else if(video_discreption.getText().toString().equals("")){
                    Toast.makeText(Video_upload.this, "Please type a password", Toast.LENGTH_SHORT).show();

                }else if(module_no.getText().toString().equals("")){
                    Toast.makeText(Video_upload.this, "Please type a password", Toast.LENGTH_SHORT).show();

                }else if(video_no.getText().toString().equals("")){
                    Toast.makeText(Video_upload.this, "Please type a password", Toast.LENGTH_SHORT).show();

                }else {
                    ref.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                        @Override
                        public void onSuccess(DocumentSnapshot documentSnapshot) {
                            if (documentSnapshot.exists())
                            {
                                Toast.makeText(Video_upload.this, "Sorry,this user exists", Toast.LENGTH_SHORT).show();
                            } else {
                                Map<String, Object> reg_entry = new HashMap<>();
                                reg_entry.put("File", file_address);
                                reg_entry.put("Module_no", module_no.getText().toString());
                                reg_entry.put("Name", urername.getText().toString());
                                reg_entry.put("Subject", slected);
                                reg_entry.put("UserId", le_userid.getText().toString());
                                reg_entry.put("Video_dis", video_discreption.getText().toString());
                                reg_entry.put("Video_no", video_no.getText().toString());
                                //   String myId = ref.getId();
                                firebaseFirestore.collection("teacher")
                                        .add(reg_entry)
                                        .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                            @Override
                                            public void onSuccess(DocumentReference documentReference) {
                                                Intent mainpage = new Intent(Video_upload.this, LoginActivity.class);
                                                startActivity(mainpage);
                                                Toast.makeText(Video_upload.this, "Successfully added", Toast.LENGTH_SHORT).show();
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Log.d("Error", e.getMessage());
                                            }
                                        });
                            }
                        }
                    });
                }
            }
            });
        iv_attachments.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showFileChooser();
            }
        });
        txt_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadFile();
            }
        });

        }
   private void showFileChooser() {
       Intent intent = new Intent();
       intent.setType("video/*");
       intent.setAction(Intent.ACTION_GET_CONTENT);
       startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
   }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                //imageView.setImageBitmap(bitmap);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
         slected = subject[position];
         Log.d("TAG","Selected======="+slected.toString());
        Toast.makeText(getApplicationContext(),subject[position] , Toast.LENGTH_LONG).show();
    }
    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }
    public String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }
    private void uploadFile() {
        //checking if file is available
        if (filePath != null) {
            //displaying progress dialog while image is uploading
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading");
            progressDialog.show();

            //getting the storage reference
            StorageReference sRef = storageReference.child(Constants.STORAGE_PATH_UPLOADS + System.currentTimeMillis() + "." + getFileExtension(filePath));

            //adding the file to reference
            sRef.putFile(filePath)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            //dismissing the progress dialog
                            progressDialog.dismiss();

                            //displaying success toast
                            Toast.makeText(getApplicationContext(), "File Uploaded ", Toast.LENGTH_LONG).show();

                            //creating the upload object to store uploaded image details
                           // Upload upload = new Upload(editTextName.getText().toString().trim(), taskSnapshot.getDownloadUrl().toString());

                            //adding an upload to firebase database
                            String uploadId = mDatabase.push().getKey();
                            mDatabase.child(uploadId);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), exception.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            //displaying the upload progress
                            double progress = (100.0 * taskSnapshot.getBytesTransferred()) / taskSnapshot.getTotalByteCount();
                            progressDialog.setMessage("Uploaded " + ((int) progress) + "%...");
                        }
                    });
        } else {
            //display an error if no file is selected
        }
    }

}










*/
