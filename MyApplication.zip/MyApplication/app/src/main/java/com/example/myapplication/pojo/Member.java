package com.example.myapplication.pojo;

public class Member {
    private String name;
    private String Videourl;
    private String search;
    private String Username;
    String username ;
    String le_Userid ;
    String  videodiscription ;
    String reg_entry ;
    String subject;
    String teachername;

    String module ;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }



    public String getTeachername() {
        return teachername;
    }

    public void setTeachername(String teachername) {
        this.teachername = teachername;
    }



    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getLe_Userid() {
        return le_Userid;
    }

    public void setLe_Userid(String le_Userid) {
        this.le_Userid = le_Userid;
    }

    public String getVideodiscription() {
        return videodiscription;
    }

    public void setVideodiscription(String videodiscription) {
        this.videodiscription = videodiscription;
    }

    public String getReg_entry() {
        return reg_entry;
    }

    public void setReg_entry(String reg_entry) {
        this.reg_entry = reg_entry;
    }



    public Member(){}
    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVideourl() {
        return Videourl;
    }

    public void setVideourl(String videourl) {
        Videourl = videourl;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }
}
