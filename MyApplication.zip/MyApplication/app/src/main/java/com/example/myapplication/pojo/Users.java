package com.example.myapplication.pojo;

public class Users {


    private String name;
    private String password;
    private String date;

    public Users(String name, String password,String date) {
        this.name = name;
        this.password = password;
        this.date = date;
    }

    public Users() {

    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

}
