package com.example.myapplication.util;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.example.myapplication.activity.PlayLactureActivity;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.extractor.ExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.AdaptiveTrackSelection;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.BandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultBandwidthMeter;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSourceFactory;

public class ViewHolder extends RecyclerView.ViewHolder {
    SimpleExoPlayer exoPlayer;
    PlayerView playerView;
    String userId = null;
    String videourl = null;
    Application application;



    public void setExoplayer(Application application , String pname,String mno,String lno,String vdesc, String Videourl){
          videourl = Videourl;
          this.application =application;

      //  TextView textView = itemView.findViewById(R.id.txt_profersername);
        TextView txt_profersername = itemView.findViewById(R.id.txt_profersername);
        TextView txt_module_no = itemView.findViewById(R.id.txt_module_no);
        TextView txt_lectureno = itemView.findViewById(R.id.txt_lectureno);
        TextView txt_vdiscription = itemView.findViewById(R.id.txt_vdiscription);
        playerView = itemView.findViewById(R.id.exoplayer_item);

        txt_profersername.setText(pname);
        txt_module_no.setText(mno);
        txt_lectureno.setText(lno);
        txt_vdiscription.setText(vdesc);

        try {
            BandwidthMeter bandwidthMeter = new DefaultBandwidthMeter.Builder(application).build();
            TrackSelector trackSelector = new DefaultTrackSelector(new AdaptiveTrackSelection.Factory(bandwidthMeter));
            exoPlayer = (SimpleExoPlayer) ExoPlayerFactory.newSimpleInstance(application);
            Uri video = Uri.parse(Videourl);
            DefaultHttpDataSourceFactory dataSourceFactory = new DefaultHttpDataSourceFactory("video");
            ExtractorsFactory extractorsFactory = new DefaultExtractorsFactory();
            MediaSource mediaSource = new ExtractorMediaSource(video,dataSourceFactory,extractorsFactory,null,null);
            playerView.setPlayer(exoPlayer);
            exoPlayer.prepare(mediaSource);
            exoPlayer.setPlayWhenReady(false);

        }catch (Exception e){
            Log.e("ViewHolder","exoplayer error"+e.toString());
        }



    }
    public ViewHolder(@NonNull View itemView) {
        super(itemView);

        itemView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent i = new Intent(application, PlayLactureActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                 i.putExtra("userid",userId);
                 i.putExtra("videourl",videourl);
                application.startActivity(i);

            }
        });
        itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {

                mClickListener.onItemLongClick(view, getAdapterPosition());
                return false;
            }
        });


    }


    private Clicklistener mClickListener;

    public interface Clicklistener{
        void onItemClick(View view,int position);
        void onItemLongClick(View view ,int position);

    }

    public void setOnClicklistener(Clicklistener clicklistener){
        mClickListener = clicklistener;
    }
}
