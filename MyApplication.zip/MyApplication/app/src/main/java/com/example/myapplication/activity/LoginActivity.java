package com.example.myapplication.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.MainActivity;
import com.example.myapplication.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;


public class LoginActivity extends AppCompatActivity {

    EditText username,password;
    Button loginBtn;
    TextView txt_signup;
    Boolean p=false;
    FirebaseFirestore db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = FirebaseFirestore.getInstance();
        initilize();
    }
    public void initilize(){
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginBtn = findViewById(R.id.loginBtn);
        txt_signup = findViewById(R.id.txt_signup);


        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  progressBar.setVisibility(View.VISIBLE);
                db.collection("user")
                        .get()
                        .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                if(task.isSuccessful()){
                                    String a1 = username.getText().toString().trim();
                                    String b1 = password.getText().toString().trim();
                                    for(QueryDocumentSnapshot doc : task.getResult()) {
                                        String a = doc.getString("email");
                                        String b = doc.getString("password");
                                        if(a!=null||b!=null){
                                            if (a.equalsIgnoreCase(a1) & b.equalsIgnoreCase(b1)) {
                                                Intent home = new Intent(LoginActivity.this, MainActivity.class);
                                                startActivity(home);
                                                Toast.makeText(LoginActivity.this, "Logged In", Toast.LENGTH_SHORT).show();
                                                p = true;
                                                break;
                                            }
                                        }

                                    }
                                    if(!p){
                                    if(a1.equalsIgnoreCase("admin@gmail.com") & b1.equalsIgnoreCase("admin")) {
                                            Intent home = new Intent(LoginActivity.this, UploadingActivity.class);
                                            startActivity(home);
                                            Toast.makeText(LoginActivity.this, "Logged In", Toast.LENGTH_SHORT).show();
                                    }else
                                            Toast.makeText(LoginActivity.this, "Cannot login,incorrect Email and Password", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        });
            }
        });

        txt_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this,Register.class);
                startActivity(i);
            }
        });

    }
}