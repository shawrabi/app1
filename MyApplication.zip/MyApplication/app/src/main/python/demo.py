import numpy as np
def sumtwo(number1, number2 ):
	# Store input numbers
	num1 = int(number1)
	num2 = int(number2)

	# Add two numbers
	summ = float(num1) + float(num2)
	return str(summ)