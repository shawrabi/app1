from NeuroPy import NeuroPy
from time import sleep
import csv
import os
import errno

def checkFileExistByOSPath(file_path):

    ret = False
    # If this file object exist.
    if(os.path.exists(file_path)):
        ret = True
        #print(file_path + " exist. ")
        # If this is a file.
        if(os.path.isfile(file_path)):
            print(" and it is a file.")
        # This is a directory.
        else:
            print(" and it is a directory.")
    else:
        ret = False
        #print(file_path + " do not exist.")

    return ret

def createNewFile(file_path):
	global f
	f = open(file_path, 'wb')
	writer = csv.writer(f)
	writer.writerow(['attention','meditation','rawValue','delta','theta','lowAlpha','highAlpha','lowBeta','highBeta','lowGamma','midGamma','blinkStrength','poor signal'])

def neuStart():
    neuropy.start()
def neuStop():
    print("exiting!")
    neuropy.stop()



def Unsuccess(name):
    global counter
    counter=0
    #print("NIT")
    return 'welcome %s' % name



def success(name):
    global counter
    global s
    global f
    #print('On Over')
    file_path=s+".csv"
    #print("file_path",file_path)
    fileExist =checkFileExistByOSPath(file_path)
    if(not fileExist):
        createNewFile(file_path)
        #f= open(file_path,"wb")
    #if( success.counter != 0):

    neuStart()
    counter +=1
    #print("started writing!")
    #print("press ctrl+c when u r done with the video")
    sleep(1)
    with f:
        writer = csv.writer(f)

        while (counter):
            #try:
              m = neuropy.meditation
              a = neuropy.attention
              r = neuropy.rawValue
              d = neuropy.delta
              t = neuropy.theta
              la = neuropy.lowAlpha
              ha = neuropy.highAlpha
              lb = neuropy.lowBeta
              hb = neuropy.highBeta
              lg = neuropy.lowGamma
              mg = neuropy.midGamma
              bs = neuropy.blinkStrength
              s = neuropy.poorSignal
              writer.writerow([a,m,d,t,la,ha,lb,hb,lg,mg,bs,s]);
              sleep(1) # sleep for 1s

              #print("working",counter)

            #except KeyboardInterrupt:
              if(counter==0):
                  neuStop()
                  f.close()
                  print("Not working")
                  break



    return 'welcome %s' % name